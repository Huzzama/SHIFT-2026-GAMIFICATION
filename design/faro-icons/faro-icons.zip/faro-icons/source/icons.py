"""
FARO icon family - masters.

Grammar (inherited from src/components/Icon.tsx, the existing graphic line):
  * 24 x 24 grid, 2px safe margin, flat side elevation (no perspective)
  * one stroke, round caps + round joins, 1.8 at 24px
  * outline by default; ONE solid element per icon, and only where it
    carries meaning (the light, the direction, the "done")
  * three shared motifs tie the family together:
      - the water line: calm sine = rhythm/progress, cusp chop = friction,
        dead flat = safe harbor
      - the sail: the same curved main-sail for every ship
      - the diamond = light/signal (compass needle, beacon, reward token)

Every element is drawn in currentColor. Accent parts carry class="acc" and
are filled with the accent colour a board chooses (mint / violet / forest /
orange) - or with currentColor when the icon is shown monochrome.
"""
from math import cos, sin, radians

# ------------------------------------------------------------------ helpers

def wave(x0, x1, y, half=3.0, amp=1.0, start_up=True):
    """Calm sine water line built from cubic humps (same maths as the
    existing `wave` glyph)."""
    k = amp * 1.33
    h = half
    s = -1 if start_up else 1
    d = f"M{x0:g} {y:g}c{h/3:.2f} {s*k:.2f} {2*h/3:.2f} {s*k:.2f} {h:.2f} 0"
    x = x0 + h
    sign = -s
    while x + h <= x1 + 0.01:
        d += f"s{2*h/3:.2f} {sign*k:.2f} {h:.2f} 0"
        sign = -sign
        x += h
    return d


def chop(x0, x1, y, w=3.0, amp=2.0):
    """Rough water: rounded crests meeting in pointed troughs."""
    d = f"M{x0:g} {y:g}"
    x = x0
    while x + w <= x1 + 0.01:
        d += f"q{w/2:.2f} {-amp*2:.2f} {w:.2f} 0"
        x += w
    return d


def diamond(cx, cy, rx, ry=None):
    ry = ry if ry is not None else rx
    return f"M{cx:g} {cy-ry:g}L{cx+rx:g} {cy:g}L{cx:g} {cy+ry:g}L{cx-rx:g} {cy:g}Z"


def sail(mast_x, top, foot, reach, belly=0.55):
    """The FARO main-sail: attached to the mast, curved leech bulging aft
    (left), flat foot. `reach` = how far the foot extends from the mast."""
    cx = mast_x - reach * belly
    cy = top + (foot - top) * 0.42
    return (f"M{mast_x:g} {top:g}Q{cx:.2f} {cy:.2f} {mast_x-reach:g} {foot:g}"
            f"H{mast_x:g}Z")


def jib(x, top, foot, reach):
    cx = x + reach * 0.62
    cy = top + (foot - top) * 0.45
    return f"M{x:g} {top:g}Q{cx:.2f} {cy:.2f} {x+reach:g} {foot:g}H{x:g}Z"


def P(d, extra=""):
    return f'<path d="{d}" {extra}/>'


def C(cx, cy, r, extra=""):
    return f'<circle cx="{cx:g}" cy="{cy:g}" r="{r:g}" {extra}/>'


ACC = 'class="acc" stroke="none"'
ACC_STROKED = 'class="acc"'  # filled accent that keeps the outline

# ------------------------------------------------------------- the family

def lighthouse(state="rest"):
    """FARO. The wordmark's lighthouse in outline: tapered tower, lantern,
    gallery, door, and the brand's two beam plates. The plates point OUT
    over the sea, never down at the ship: guidance without control.
    States: rest | selected | guiding (the only place light is 'on')."""
    lantern = {"rest": 'fill="none"', "selected": 'class="acc-solid"',
               "guiding": 'class="acc"'}[state]
    plates = "M8.1 7 3.4 6v4.3l4.7-1ZM15.9 7l4.7-1v4.3l-4.7-1Z"
    return ((P(plates, 'class="acc beam"') if state == "guiding" else "")
            + P(plates)
            + P("M9.2 5.6 12 3l2.8 2.6")
            + f'<rect x="9.6" y="5.6" width="4.8" height="4" rx="0.7" {lantern}/>'
            + P("M8.6 9.6h6.8")
            + P("M10.1 9.6 8.9 20.2M13.9 9.6l1.2 10.4")
            + P("M11 20.2v-2.4a1 1 0 0 1 2 0v2.4")
            + P("M6 20.2h12"))



def compass(state="rest"):
    """Next Best Action. The needle points to ONE waypoint on the bezel:
    one direction, one action - not a 32-point travel rose."""
    a = radians(-45)
    ux, uy = cos(a), sin(a)          # NE
    px, py = -uy, ux                 # perpendicular
    L, W = 5.4, 1.9
    tip = (12 + ux*L, 12 + uy*L)
    tail = (12 - ux*L, 12 - uy*L)
    s1 = (12 + px*W, 12 + py*W)
    s2 = (12 - px*W, 12 - py*W)
    head = f"M{tip[0]:.2f} {tip[1]:.2f}L{s1[0]:.2f} {s1[1]:.2f}L12 12L{s2[0]:.2f} {s2[1]:.2f}Z"
    body = (f"M{tip[0]:.2f} {tip[1]:.2f}L{s1[0]:.2f} {s1[1]:.2f}L{tail[0]:.2f} {tail[1]:.2f}"
            f"L{s2[0]:.2f} {s2[1]:.2f}Z")
    wp = (12 + ux*8.6, 12 + uy*8.6)
    head_cls = 'class="acc-solid"' if state == "rest" else 'class="acc"'
    return (C(12, 12, 8.6)
            + P(head, head_cls)
            + P(body)
            + C(wp[0], wp[1], 1.45, 'class="acc-mark" stroke-width="0"'))


def ship(extra=""):
    """The student. One hull raked forward (bow right = forward in time),
    one main-sail, one jib. Reads at 16px."""
    return (P("M3.8 15.2h16.8l-3.3 3.6H5.5Z")
            + P("M11.6 3.4v11.8")
            + P(sail(11.6, 3.9, 13.2, 5.4))
            + P(jib(13.1, 5.6, 13.2, 4.4))
            + extra)


def route(state="rest"):
    """The Journey: an organic course line with a harbour ring at the
    start, a checkpoint on the way and the destination pennant."""
    return (C(5.8, 18.4, 1.9)
            + P("M5.8 16.5C5.8 11.2 17.6 13.4 17.6 8.4")
            + C(11.7, 12.35, 1.3, 'class="acc-mark" stroke-width="0"')
            + P("M17.6 8.4V3.4")
            + P("M17.6 3.6l3.4 1.5-3.4 1.5", 'class="acc-solid" stroke-linejoin="round"'))


def harbor():
    """Start. The anchor you weigh when you set out. Its ring is the first
    point of the course - the same hollow ring that opens the Route."""
    return (C(12, 4.6, 1.7, 'class="acc"')
            + P("M12 6.3v13.9")
            + P("M8.6 9.2h6.8")
            + P("M4.8 13.4c.4 4 3.4 6.8 7.2 6.8s6.8-2.8 7.2-6.8")
            + P("M3.4 14.8l1.4-1.6 1.6 1.4M20.6 14.8l-1.4-1.6-1.6 1.4"))



def buoy(state="upcoming"):
    """Checkpoint. A navigation buoy. The state lives in the body and the
    top light, not in extra colours:
      completed = body filled         current  = top light on
      upcoming  = outline             locked   = dashed, quiet"""
    body = "M8.8 17.2 10.2 9h3.6l1.4 8.2Z"
    body_attr = ""
    light_attr = 'fill="none"'
    extra_attr = ""
    if state == "completed":
        body_attr = 'class="acc-done"'
        light_attr = 'class="acc-done"'
    elif state == "current":
        light_attr = 'class="acc"'
    elif state == "locked":
        extra_attr = 'opacity="0.38"'
    out = (P(body, body_attr + " " + extra_attr)
           + P("M9.5 13.1h5", extra_attr if state != "completed" else 'class="band-knock"')
           + P("M12 9V6.6", extra_attr)
           + C(12, 5, 1.6, light_attr + " " + extra_attr)
           + P(wave(3, 21, 18.6, half=3, amp=0.8), 'opacity="0.5"' if state == "locked" else ""))
    return out


def storm():
    """Friction. Rough water under a low cloud. No lightning, no rain,
    no dark mass: a stretch of chop you sail through."""
    cloud = ("M8 11a3 3 0 0 1-.4-5.97A4.3 4.3 0 0 1 15.9 5a3 3 0 0 1 .6 6Z")
    return (P(cloud)
            + P(chop(3, 21, 16.2, w=4.5, amp=1.15))
            + P(chop(5.25, 18.75, 20.2, w=4.5, amp=1.15)))


def safe_harbor(small=False):
    """Recovery / pause. Two harbour walls, a sheltering arc, the ship
    inside - and the only perfectly flat water in the family.
    'You are safe. Let's reorganise.'"""
    return (P("M3 19.2h18")
            + P("M4.6 19.2v-6.6M19.4 19.2v-6.6")
            + ("" if small else P("M4.6 12.6a7.4 7.4 0 0 1 14.8 0", 'stroke-dasharray="0.1 2.6"'))
            + P("M8.4 15.6h7.2l-1.3 2h-4.6Z")
            + P("M12 8.8v6.8")
            + P(sail(12, 9.2, 14, 3), 'class="acc"'))



def destination():
    """Course completion. A low coast on the water with the pennant
    planted: arrived, calmly. (The same pennant closes the Route.)"""
    return (P("M4.5 17.8c2.2-3.3 5-4.6 7.5-4.6s5.3 1.3 7.5 4.6")
            + P(wave(3, 21, 20, half=3, amp=0.8))
            + P("M12 13.2V4.2")
            + P("M12 4.4l5 2.2-5 2.2", 'class="acc-solid"'))


def horizon():
    """Purpose. Not where this course ends - where the whole journey is
    going. A light on the horizon line, with its reflection on the sea."""
    return (P("M2.8 14.6h18.4")
            + P("M7 14.6a5 5 0 0 1 10 0", 'class="acc-line"')
            + P("M8.6 17.6h6.8M10.4 20.4h3.2")
            + P("M12 4.2v2M5.9 6.7l1.3 1.4M18.1 6.7l-1.3 1.4"))


def rhythm():
    """Learning rhythm. A current, not a flame. Three lines of the same
    calm water, one with the student riding it."""
    return (P(wave(6, 21, 7.6, half=3, amp=1))
            + P(wave(3, 21, 12.4, half=3, amp=1), 'class="acc-line"')
            + P(wave(3, 18, 17.2, half=3, amp=1)))


def life_buoy():
    """SOS. Recognisable at once, drawn calm: brand bands, not alarm red."""
    out = C(12, 12, 8.6) + C(12, 12, 4.3)
    for ang in (45, 135, 225, 315):
        a0, a1 = radians(ang - 13), radians(ang + 13)
        R, r = 8.6, 4.3
        pts = [(12 + R*cos(a0), 12 + R*sin(a0)), (12 + R*cos(a1), 12 + R*sin(a1)),
               (12 + r*cos(a1), 12 + r*sin(a1)), (12 + r*cos(a0), 12 + r*sin(a0))]
        d = (f"M{pts[0][0]:.2f} {pts[0][1]:.2f}A{R} {R} 0 0 1 {pts[1][0]:.2f} {pts[1][1]:.2f}"
             f"L{pts[2][0]:.2f} {pts[2][1]:.2f}A{r} {r} 0 0 0 {pts[3][0]:.2f} {pts[3][1]:.2f}Z")
        out += P(d, 'class="acc-solid"')
    return out


def fleet():
    """Community. Every student is a ship; together they are a fleet.
    Three sails of the ship's family on one shared sea."""
    return (P(sail(8.4, 3.6, 14.2, 4.8))
            + P("M4 16.2h6")
            + P(sail(14.6, 6.8, 14.2, 3.8), 'class="acc"')
            + P("M11 16.2h5")
            + P(sail(20.2, 9.6, 14.2, 3), '')
            + P("M17.2 16.2h3.8")
            + P(wave(3, 21, 19.6, half=3, amp=0.8)))


def beacon(state="earned"):
    """Achievement. A navigation mark on the water: post, light, one pulse.
    The diamond is the family's sign for light. Earned = light on.
    Celebrates persistence, never a click."""
    fill = 'class="acc"' if state == "earned" else 'fill="none"'
    op = "" if state == "earned" else 'opacity="0.4"'
    return (P(diamond(12, 6.8, 2.8, 3.3), fill)
            + P("M7.4 3.9a5.6 5.6 0 0 0 0 5.8M16.6 3.9a5.6 5.6 0 0 1 0 5.8", op)
            + P("M12 10.1v6.6")
            + P("M9.4 16.7h5.2")
            + P(wave(3, 21, 19.6, half=3, amp=0.8)))



def reward():
    """Rewards. A refined token marked with the light-diamond, a second
    token behind it: a balance that grows toward the semester goal.
    No chest, no cartoon gold."""
    r, gap, off = 6.4, 1.4, 3.8
    front = (10.3, 13.7)
    back = (front[0] + off, front[1] - off)
    p, q = _circle_intersections(back, r, front, r + gap)
    arc = f"M{q[0]:.2f} {q[1]:.2f}A{r} {r} 0 1 1 {p[0]:.2f} {p[1]:.2f}"
    return (P(arc)
            + C(front[0], front[1], r)
            + C(front[0], front[1], 4.1, 'opacity="0.45"')
            + P(diamond(front[0], front[1], 1.8, 2.2), 'class="acc-solid"'))


def _circle_intersections(c1, r1, c2, r2):
    from math import sqrt
    (x1, y1), (x2, y2) = c1, c2
    d = sqrt((x2-x1)**2 + (y2-y1)**2)
    a = (r1*r1 - r2*r2 + d*d) / (2*d)
    h = sqrt(max(r1*r1 - a*a, 0))
    xm, ym = x1 + a*(x2-x1)/d, y1 + a*(y2-y1)/d
    return ((xm + h*(y2-y1)/d, ym - h*(x2-x1)/d), (xm - h*(y2-y1)/d, ym + h*(x2-x1)/d))



def recalculate():
    """Recalculating your route. The straight course breaks off (dotted,
    left behind); a new course bends up from the break and still reaches
    the same pennant. The route changes; the destination stays possible."""
    return (C(4.4, 18.2, 1.7)
            + P("M6.1 18.2h3.4")
            + P("M12.4 18.2H20", 'stroke-dasharray="0.1 2.6" opacity="0.5"')
            + P("M9.5 18.2c3.2 0 4.4-2.4 5-5.2.5-2.4 1.1-4.2 2.9-4.4", 'class="acc-line"')
            + P("M17.6 8.6V3.4")
            + P("M17.6 3.6l3.4 1.5-3.4 1.5", 'class="acc-solid"'))



# ship states - the ship is the student's signature; it changes situation,
# never shape.

def ship_sailing():
    return (P("M3.8 13.8h16.8l-3.3 3.6H5.5Z")
            + P("M11.6 2v11.8")
            + P(sail(11.6, 2.5, 11.8, 5.4))
            + P(jib(13.1, 4.2, 11.8, 4.4))
            + P(wave(3, 21, 20.4, half=3, amp=0.8)))



def ship_rough():
    g = ('<g transform="rotate(-9 12 14)">'
         + P("M3.8 13.4h16.8l-3.3 3.6H5.5Z")
         + P("M11.6 1.8v11.6")
         + P(sail(11.6, 2.3, 11.4, 5.4))
         + P(jib(13.1, 4, 11.4, 4.4)) + '</g>')
    return g + P(chop(1.5, 22.5, 20.6, w=4.2, amp=1.2))



def ship_returning():
    """Heading back toward the harbour wall; the water calms as it nears."""
    g = ('<g transform="translate(26.4 0) scale(-1 1)">'
         + P("M3.8 13.6h13.4l-2.7 3H5.2Z")
         + P("M10 4v9.6")
         + P(sail(10, 4.4, 11.8, 4.4))
         + P(jib(11.3, 5.8, 11.8, 3.6)) + '</g>')
    return (g
            + P("M3.4 19.6v-7.2")
            + P("M3.4 19.6h6.2")
            + P(wave(9.6, 21.6, 19.6, half=3, amp=0.8)))



def ship_new_route():
    return (P("M2.4 16.6h11l-2.2 2.4H3.6Z")
            + P("M7.2 8.6v8")
            + P(sail(7.2, 9, 15, 3.6))
            + P(jib(8.2, 10.2, 15, 2.8))
            + P("M14.6 15.2c3.4-1 5.2-4.4 5.4-9.4", 'class="acc-line" stroke-dasharray="0.1 2.5"')
            + P("M20 5.8V2.6", '')
            + P("M20 2.7l2.2 1-2.2 1", 'class="acc-solid"'))


# route nodes - the tiny form of the buoy logic, used ON the course line
def node(state):
    if state == "completed":
        return (C(12, 12, 5, 'class="acc-done"')
                + P("m9.7 12.1 1.6 1.6 3-3.3", 'class="knock"'))
    if state == "current":
        return C(12, 12, 8, 'opacity="0.35"') + C(12, 12, 5) + C(12, 12, 2.4, 'class="acc-mark" stroke-width="0"')
    if state == "upcoming":
        return C(12, 12, 5)
    return C(12, 12, 5, 'stroke-dasharray="0.1 2.35" opacity="0.6"')


ICONS = {
    # tier 1 - identity
    "lighthouse": ("Lighthouse", "FARO Mentor · guidance", 1, lighthouse),
    "compass": ("Compass", "Next Best Action · Home", 1, compass),
    "ship": ("Ship", "The student", 1, ship),
    "route": ("Route", "Journey", 1, route),
    # tier 2 - learning states
    "harbor": ("Harbor", "Start · onboarding", 2, harbor),
    "checkpoint": ("Checkpoint", "Milestone · module", 2, lambda: buoy("upcoming")),
    "storm": ("Storm", "Friction · difficulty", 2, storm),
    "safe-harbor": ("Safe Harbor", "Recovery · pause", 2, safe_harbor),
    "destination": ("Destination", "Course completion", 2, destination),
    "rhythm": ("Rhythm", "Learning rhythm", 2, rhythm),
    "recalculate": ("Recalculate", "New route after disruption", 2, recalculate),
    # tier 3 - support
    "life-buoy": ("Life Buoy", "SOS · immediate help", 3, life_buoy),
    "fleet": ("Fleet", "Community · Study Rooms", 3, fleet),
    "beacon": ("Beacon", "Achievement · resilience", 3, beacon),
    "reward": ("Reward", "FARO Points · tiers", 3, reward),
    "horizon": ("Horizon", "Purpose · long-term goal", 3, horizon),
}


def svg(inner, size=24, color="#14302c", accent=None, stroke_px=None,
        done=None, bg_knock="#ffffff", mono=False, accent_line=None):
    """Wrap an icon body. `stroke_px` = the stroke in rendered pixels (the
    optical-size rule); defaults to the 1.8-at-24 base.

    Accent rule: an accent FILL always sits inside the icon's own line
    (so light mint still reads on white). Free-standing marks and accent
    LINES use `accent_line`, the darker step of the same hue on light."""
    sw = 1.8 if stroke_px is None else stroke_px * 24 / size
    acc = color if (mono or accent is None) else accent
    accl = color if (mono or accent is None) else (accent_line or accent)
    dn = color if (mono or done is None) else done
    body = (inner.replace('class="acc beam"', f'fill="{acc}" opacity="0.42"')
                 .replace('class="acc-solid"', f'fill="{acc}"')
                 .replace('class="acc-mark"', f'fill="{accl}"')
                 .replace('class="acc-done"', f'fill="{dn}"')
                 .replace('class="acc-line"', f'stroke="{accl}"')
                 .replace('class="knock"', f'stroke="{bg_knock}"')
                 .replace('class="band-knock"', f'stroke="{bg_knock}"')
                 .replace('class="acc"', f'fill="{acc}"'))
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}" '
            f'viewBox="0 0 24 24" fill="none" stroke="{color}" stroke-width="{sw:.3f}" '
            f'stroke-linecap="round" stroke-linejoin="round">{body}</svg>')


def optical_stroke(size):
    """Stroke in px for a rendered size - thin enough to stay elegant large,
    heavy enough to survive 16px."""
    table = {16: 1.5, 20: 1.6, 24: 1.8, 32: 2.1, 40: 2.4, 48: 2.6, 64: 3.0,
             96: 3.6, 128: 4.2, 256: 7.0, 512: 13.0}
    return table.get(size, 1.8 * (size / 24) ** 0.62)
