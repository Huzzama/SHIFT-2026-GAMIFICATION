"""Export every icon and state as transparent 512 px PNGs (light / dark / mono) + SVG masters."""
import asyncio, os
from playwright.async_api import async_playwright
import icons as I
from boards import LIGHT, DARK, SEM

ITEMS = []
for k, (name, use, tier, fn) in I.ICONS.items():
    ITEMS.append((f"t{tier}-{k}", fn(), SEM[k]))
ITEMS += [
    ("state-lighthouse-selected", I.lighthouse("selected"), "mint"),
    ("state-lighthouse-guiding", I.lighthouse("guiding"), "mint"),
    ("state-checkpoint-completed", I.buoy("completed"), "mint"),
    ("state-checkpoint-current", I.buoy("current"), "mint"),
    ("state-checkpoint-upcoming", I.buoy("upcoming"), "mint"),
    ("state-checkpoint-locked", I.buoy("locked"), "mint"),
    ("state-node-completed", I.node("completed"), "mint"),
    ("state-node-current", I.node("current"), "mint"),
    ("state-node-upcoming", I.node("upcoming"), "mint"),
    ("state-node-locked", I.node("locked"), "mint"),
    ("state-ship-sailing", I.ship_sailing(), None),
    ("state-ship-rough-water", I.ship_rough(), None),
    ("state-ship-returning", I.ship_returning(), None),
    ("state-ship-new-route", I.ship_new_route(), "mint"),
    ("state-beacon-not-yet", I.beacon("unearned"), "violet"),
    ("nav-safe-harbor-small", I.safe_harbor(small=True), "mint"),
]
SIZE, STROKE = 512, 19.2
OUT = "out/icons"


def variant(body, sem, pal, mono=False, knock=None):
    acc = pal[sem] if sem else None
    accl = pal[sem + "_line"] if sem else None
    return I.svg(body, SIZE, color=pal["ink"], accent=acc, accent_line=accl, stroke_px=STROKE,
                 done=pal["forest"], bg_knock=knock or pal["knock"], mono=mono)


def svg_master(body):
    """Code-ready master: currentColor lines, accent via CSS custom property."""
    s = I.svg(body, 24, color="currentColor", accent="ACC", accent_line="ACCL", done="DONE",
              bg_knock="KNOCK")
    return (s.replace('fill="ACC"', 'style="fill:var(--faro-accent, currentColor)"')
             .replace('stroke="ACCL"', 'style="stroke:var(--faro-accent-line, var(--faro-accent, currentColor))"')
             .replace('fill="ACCL"', 'style="fill:var(--faro-accent-line, var(--faro-accent, currentColor))"')
             .replace('fill="DONE"', 'style="fill:var(--faro-done, currentColor)"')
             .replace('stroke="KNOCK"', 'style="stroke:var(--faro-surface, #fff)"'))


async def main():
    for d in ("light", "dark", "mono", "svg"):
        os.makedirs(f"{OUT}/{d}", exist_ok=True)
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await b.new_page(viewport={"width": SIZE, "height": SIZE})
        for name, body, sem in ITEMS:
            for folder, pal, mono, knock in (("light", LIGHT, False, "#ffffff"), ("dark", DARK, False, "#0f1e1b"),
                                             ("mono", LIGHT, True, "#ffffff")):
                html = (f'<html><body style="margin:0;background:transparent">'
                        f'{variant(body, sem, pal, mono, knock)}</body></html>')
                await pg.set_content(html)
                el = await pg.query_selector("svg")
                await el.screenshot(path=f"{OUT}/{folder}/faro-{name}.png", omit_background=True)
            open(f"{OUT}/svg/faro-{name}.svg", "w").write(svg_master(body))
        await b.close()
    print(len(ITEMS), "icons exported")

asyncio.run(main())
