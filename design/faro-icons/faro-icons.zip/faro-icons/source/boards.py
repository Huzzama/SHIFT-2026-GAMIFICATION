"""Render the FARO visual-language boards (PNG) from the icon masters."""
import asyncio, math, sys
from playwright.async_api import async_playwright
import icons as I

# ------------------------------------------------------------------ palette
LIGHT = dict(ink="#14302c", ink2="#2f4a45", ink3="#5f7571", ink4="#9fb0ac",
             mint="#5bcd8d", mint_line="#2f9a62", forest="#1f6b4a", forest_line="#1f6b4a",
             violet="#7a4fb5", violet_line="#6a3fa8", orange="#d97a2f", orange_line="#c96a24",
             knock="#ffffff")
DARK = dict(ink="#eef5f2", ink2="rgba(238,245,242,.78)", ink3="rgba(238,245,242,.58)", ink4="rgba(238,245,242,.36)",
            mint="#5bcd8d", mint_line="#5bcd8d", forest="#2a8a5e", forest_line="#7ddaa5",
            violet="#8f6cc9", violet_line="#b39ae0", orange="#e0853a", orange_line="#eb9a55",
            knock="#17322d")
TEAL = dict(DARK, knock="#1b3b37")

SEM = {"lighthouse": "mint", "compass": "mint", "ship": None, "route": "forest",
       "harbor": "mint", "checkpoint": "mint", "storm": None, "safe-harbor": "mint",
       "destination": "forest", "rhythm": "orange", "recalculate": "mint",
       "life-buoy": "mint", "fleet": "mint", "beacon": "violet", "reward": "violet",
       "horizon": "mint"}


def ic(body, size, pal=LIGHT, sem="mint", color=None, mono=False, knock=None):
    if callable(body):
        body = body()
    acc = pal[sem] if sem else None
    accl = pal[sem + "_line"] if sem else None
    return I.svg(body, size, color=color or pal["ink"], accent=acc, accent_line=accl,
                 stroke_px=I.optical_stroke(size), done=pal["forest"],
                 bg_knock=knock or pal["knock"], mono=mono)


def icon(key, size, pal=LIGHT, **kw):
    fn = I.ICONS[key][3]
    if key == "safe-harbor" and size <= 24:
        fn = lambda: I.safe_harbor(small=True)   # nav-size cut: the dotted shelter drops
    return ic(fn, size, pal, SEM[key], **kw)


# ------------------------------------------------------------------ page css
CSS = """
*{box-sizing:border-box}
body{margin:0;font-family:Poppins,sans-serif;color:#14302c;-webkit-font-smoothing:antialiased}
.board{width:1920px;padding:84px 96px 72px;background:#f3f6f5}
.board.dark{background:#0f1e1b;color:#eef5f2}
.eyebrow{font-size:14px;letter-spacing:.2em;text-transform:uppercase;font-weight:500;color:#2f9a62}
.dark .eyebrow{color:#5bcd8d}
h1{font-size:60px;line-height:1.08;font-weight:500;letter-spacing:-.02em;margin:14px 0 18px}
h2{font-size:30px;font-weight:500;letter-spacing:-.01em;margin:0 0 6px}
h3{font-size:20px;font-weight:500;margin:0}
.lede{font-size:21px;line-height:1.55;font-weight:300;color:#2f4a45;max-width:1040px;margin:0}
.dark .lede{color:rgba(238,245,242,.78)}
.muted{color:#5f7571}.dark .muted{color:rgba(238,245,242,.58)}
.small{font-size:14px;line-height:1.5}
.card{background:#fff;border-radius:20px;box-shadow:0 1px 2px rgba(20,48,44,.05),0 10px 28px rgba(20,48,44,.06)}
.foot{display:flex;justify-content:space-between;margin-top:56px;padding-top:22px;border-top:1px solid #e1e8e6;font-size:13px;color:#5f7571;letter-spacing:.04em}
.dark .foot{border-color:rgba(255,255,255,.12);color:rgba(238,245,242,.5)}
.section{margin-top:56px}
.sechead{display:flex;align-items:baseline;gap:18px;margin-bottom:22px}
.tag{font-size:12px;letter-spacing:.18em;text-transform:uppercase;font-weight:500;padding:6px 12px;border-radius:999px;background:#e2ebe9;color:#23504a}
.dark .tag{background:rgba(255,255,255,.08);color:#cfe3dc}
.row{display:flex;gap:16px}
.grid{display:grid;gap:16px}
.center{display:flex;align-items:center;justify-content:center}
svg{display:block}
"""


def page(inner, dark=False, num="", title=""):
    foot = (f'<div class="foot"><span>FARO · Visual language &amp; icon system · v1.0</span>'
            f'<span>{title}</span><span>{num}</span></div>')
    return (f'<html><head><meta charset="utf-8"><style>{CSS}</style></head><body>'
            f'<div class="board{" dark" if dark else ""}">{inner}{foot}</div></body></html>')


def header(eyebrow, title, lede):
    return (f'<div class="eyebrow">{eyebrow}</div><h1>{title}</h1>'
            f'<p class="lede">{lede}</p>')


# ================================================================ BOARD 00
def board_overview():
    t1 = ["lighthouse", "compass", "ship", "route"]
    t2 = ["harbor", "checkpoint", "storm", "safe-harbor", "destination", "rhythm", "recalculate"]
    t3 = ["life-buoy", "fleet", "beacon", "reward", "horizon"]
    lines = {
        "lighthouse": "FARO itself. Beam plates point out to sea, never down at the ship: guidance without control.",
        "compass": "One needle, one waypoint on the bezel. Not a travel rose: the single next step.",
        "ship": "The student. One hull raked forward, one sail, one jib. Readable at 16 px.",
        "route": "The course: a hollow ring where it starts, a pennant where it ends.",
    }
    def card1(k):
        name, use, _, fn = I.ICONS[k]
        return (f'<div class="card" style="flex:1;padding:40px 36px 34px">'
                f'<div style="height:150px;display:flex;align-items:center">{icon(k, 132)}</div>'
                f'<h2 style="margin-top:22px">{name}</h2><div class="muted" style="font-size:16px">{use}</div>'
                f'<p class="small" style="margin:16px 0 0;color:#2f4a45">{lines[k]}</p></div>')
    def cardn(k, w):
        name, use, _, fn = I.ICONS[k]
        return (f'<div class="card" style="flex:1;padding:28px 24px 24px">'
                f'<div style="height:84px;display:flex;align-items:center">{icon(k, 72)}</div>'
                f'<h3 style="margin-top:16px">{name}</h3><div class="muted small">{use}</div></div>')
    inner = header("FARO · Visual language &amp; icon system",
                   "One sea. One light. One ship.",
                   "Sixteen symbols drawn on the grid FARO already uses: 24 px, a 1.8 stroke, round ends. "
                   "They are not decoration. Each one answers a question a working adult asks when they "
                   "come back to a course: where am I, what now, and what if I fell behind.")
    inner += ('<div class="section"><div class="sechead"><span class="tag">Tier 1</span>'
              '<h2>FARO identity</h2><span class="muted">The four signatures. Most distinctive, most used.</span></div>'
              f'<div class="row">{"".join(card1(k) for k in t1)}</div></div>')
    inner += ('<div class="section"><div class="sechead"><span class="tag">Tier 2</span>'
              '<h2>Core learning states</h2><span class="muted">What is happening on the journey right now.</span></div>'
              f'<div class="row">{"".join(cardn(k, 0) for k in t2)}</div></div>')
    inner += ('<div class="section"><div class="sechead"><span class="tag">Tier 3</span>'
              '<h2>Support &amp; secondary</h2><span class="muted">Contextual. They appear when needed.</span></div>'
              f'<div class="row">{"".join(cardn(k, 0) for k in t3)}</div></div>')
    return page(inner, num="00", title="Overview")


# ================================================================ BOARD 01
def brand_glyph(h, color="#14302c"):
    w = h * 40 / 48
    return (f'<svg width="{w:.0f}" height="{h}" viewBox="0 0 40 48" fill="{color}">'
            '<path d="M0 13.5 12.5 11v6L0 19.5Z"/><path d="M40 13.5 27.5 11v6L40 19.5Z"/>'
            '<path d="M20 2 14.5 8h11L20 2Z"/><rect x="15.5" y="8" width="9" height="6" rx="0.8"/>'
            '<rect x="13.5" y="14" width="13" height="2.4" rx="0.6"/>'
            '<path d="M15.5 17.5h9L31 48h-6l-2-13h-6l-2 13h-6L15.5 17.5Zm2.3 10.5h4.4l-.7-5h-3Z"/></svg>')


def construction_grid(body, px=18, color="#14302c"):
    S = 24 * px
    g = f'<svg width="{S}" height="{S}" viewBox="0 0 24 24">'
    g += '<rect x="0" y="0" width="24" height="24" fill="#ffffff"/>'
    g += '<path d="M0 0h24v24H0Z M2 2v20h20V2Z" fill="#eaf4ef" fill-rule="evenodd"/>'
    for i in range(25):
        w = 0.05 if i % 4 else 0.08
        g += f'<path d="M{i} 0V24M0 {i}H24" stroke="#d9e3e0" stroke-width="{w}"/>'
    g += '<circle cx="12" cy="12" r="10" fill="none" stroke="#b8d9c7" stroke-width="0.07" stroke-dasharray="0.3 0.3"/>'
    g += '<rect x="4" y="2" width="16" height="20" rx="1" fill="none" stroke="#b8d9c7" stroke-width="0.07" stroke-dasharray="0.3 0.3"/>'
    clean = body.replace('class="acc"', '')
    g += (f'<g fill="none" stroke="{color}" stroke-width="1.8" stroke-linecap="round" '
          f'stroke-linejoin="round" opacity="0.9">{clean}</g>')
    g += (f'<g fill="none" stroke="#5bcd8d" stroke-width="0.09" stroke-linecap="round" '
          f'stroke-linejoin="round">{clean}</g>')
    g += '</svg>'
    return g


def motif_line(d, w=380, h=70, vb="0 0 24 4.5", color="#14302c", sw=0.28):
    return (f'<svg width="{w}" height="{h}" viewBox="{vb}" fill="none" stroke="{color}" '
            f'stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round"><path d="{d}"/></svg>')


def board_construction():
    lh = I.lighthouse()
    inner = header("Construction", "Drawn on the grid FARO already has.",
                   "The existing app icons set the rules: a 24 px canvas, a 1.8 stroke, round caps and joins, "
                   "outline first. The new family keeps every one of them, so it sits next to the current "
                   "interface without a seam.")
    specs = [("Canvas", "24 × 24, 2 px safe margin"), ("Stroke", "1.8 at 24 px · optical steps below and above"),
             ("Ends &amp; joins", "Round, always"), ("Corners", "0.7 radius on small boxes"),
             ("View", "Flat side elevation. No perspective, no 3D"),
             ("Fill", "Outline first. At most one solid element, and only when it means something"),
             ("Colour", "currentColor + one semantic accent. Never a gradient, glow or glass")]
    spec_html = "".join(f'<div style="display:flex;gap:18px;padding:13px 0;border-bottom:1px solid #e1e8e6">'
                        f'<span style="width:150px;font-weight:500">{a}</span><span class="muted">{b}</span></div>'
                        for a, b in specs)
    lineage = (f'<div class="card" style="padding:34px;display:flex;align-items:center;gap:30px;margin-top:22px">'
               f'<div style="text-align:center">{brand_glyph(150)}<div class="small muted" style="margin-top:12px">Brand mark</div></div>'
               f'<svg width="60" height="20" viewBox="0 0 60 20" fill="none" stroke="#9fb0ac" stroke-width="2" stroke-linecap="round"><path d="M2 10h52M46 3l8 7-8 7"/></svg>'
               f'<div style="text-align:center">{icon("lighthouse", 150)}<div class="small muted" style="margin-top:12px">Icon</div></div>'
               f'<p class="small" style="flex:1;margin:0;color:#2f4a45">The lighthouse icon is the brand mark translated into line: the '
               f'wordmark\'s tapered A becomes the tower, its two beam plates stay exactly where they are, '
               f'and a door gives it human scale. Same silhouette at every size.</p></div>')
    top = (f'<div class="row section" style="gap:40px;align-items:flex-start">'
           f'<div class="card" style="padding:28px">{construction_grid(lh, 20)}'
           f'<div class="small muted" style="margin-top:14px">Lighthouse on the 24 grid · true 1.8 stroke with centre-line</div></div>'
           f'<div style="flex:1"><h2>Rules</h2>{spec_html}{lineage}</div></div>')

    calm = I.wave(1, 23, 2.25, half=3, amp=1)
    rough = I.chop(1, 23, 3.4, w=4.4, amp=1.15)
    flat = "M1 2.25H23"
    def motif(title, body, text):
        return (f'<div class="card" style="flex:1;padding:30px 30px 28px">'
                f'<h3>{title}</h3><div style="margin:20px 0 16px">{body}</div>'
                f'<p class="small muted" style="margin:0">{text}</p></div>')
    water = (f'<div style="display:flex;flex-direction:column;gap:10px">'
             f'<div style="display:flex;align-items:center;gap:14px">{motif_line(calm, 170, 40)}<span class="small">Calm · rhythm, progress</span></div>'
             f'<div style="display:flex;align-items:center;gap:14px">{motif_line(rough, 170, 40)}<span class="small">Chop · friction</span></div>'
             f'<div style="display:flex;align-items:center;gap:14px">{motif_line(flat, 170, 40)}<span class="small">Flat · safe harbor</span></div></div>')
    sails = "".join(ic(b, 64, sem="mint") for b in (I.ship(), I.fleet(), I.safe_harbor(), I.ship_returning()))
    diamonds = "".join(ic(b, 64, sem=s) for b, s in ((I.compass(), "mint"), (I.beacon(), "violet"), (I.reward(), "violet")))
    rings = "".join(ic(b, 64, sem=s) for b, s in ((I.harbor(), "mint"), (I.route(), "forest"), (I.recalculate(), "mint"), (I.destination(), "forest")))
    motifs = (f'<div class="section"><div class="sechead"><span class="tag">Motifs</span><h2>Four shapes hold the family together</h2></div>'
              f'<div class="row">'
              + motif("The water line", water, "One line, three tempers. The state of the sea is the state of the student.")
              + motif("The sail", f'<div class="row" style="gap:18px">{sails}</div>', "Every ship carries the same curved main-sail. The student is always recognisable, alone or in the fleet.")
              + motif("The diamond = light", f'<div class="row" style="gap:18px">{diamonds}</div>', "Where there is a diamond there is light: a direction, a signal, value earned.")
              + motif("Ring → pennant", f'<div class="row" style="gap:18px">{rings}</div>', "Every course starts in a hollow ring and ends at a pennant, even when it has to bend.")
              + '</div></div>')
    return page(inner + top + motifs, num="01", title="Construction")


# ================================================================ BOARD 02
def board_story():
    steps = [("Start", "Harbor", I.harbor, "mint", "Where does it begin?"),
             ("Journey", "Route", I.route, "forest", "Where am I going?"),
             ("Direction", "Compass", I.compass, "mint", "What should I do next?"),
             ("Progress", "Ship · sailing", I.ship_sailing, None, "Where am I?"),
             ("Difficulty", "Ship · rough water", I.ship_rough, None, "What if life gets in the way?"),
             ("Recovery", "Safe Harbor", I.safe_harbor, "mint", "Can I stop without losing it?"),
             ("Recalculation", "Recalculate", I.recalculate, "mint", "How do I get back on track?"),
             ("New direction", "Ship · new route", I.ship_new_route, "mint", "Is it still possible?"),
             ("Completion", "Destination", I.destination, "forest", "Did I make it?")]
    n = len(steps)
    colw = 1728 / n
    # course line behind the steps
    y = 96
    pts = [(colw * (i + .5), y + (18 if i % 2 else -18)) for i in range(n)]
    d = f"M{pts[0][0]:.1f} {pts[0][1]:.1f}"
    for a, b in zip(pts, pts[1:]):
        mx = (a[0] + b[0]) / 2
        d += f"C{mx:.1f} {a[1]:.1f} {mx:.1f} {b[1]:.1f} {b[0]:.1f} {b[1]:.1f}"
    line = (f'<svg width="1728" height="200" style="position:absolute;left:0;top:0" fill="none">'
            f'<path d="{d}" stroke="#c9d6d2" stroke-width="2.4" stroke-dasharray="0.1 9" stroke-linecap="round"/></svg>')
    cells = ""
    for i, (step, name, fn, sem, q) in enumerate(steps):
        storm_bg = "background:#eef2f1;" if step == "Difficulty" else ""
        cells += (f'<div style="position:absolute;left:{colw*i:.1f}px;top:0;width:{colw:.1f}px;text-align:center">'
                  f'<div style="height:200px;position:relative"><div style="position:absolute;left:50%;margin-left:-64px;top:{36 + (18 if i % 2 else -18)}px;width:128px;height:128px;border-radius:64px;{storm_bg}'
                  f'background:{"#eef2f1" if step=="Difficulty" else "#ffffff"};box-shadow:0 1px 2px rgba(20,48,44,.05),0 10px 24px rgba(20,48,44,.07);'
                  f'display:flex;align-items:center;justify-content:center">{ic(fn, 80, sem=sem)}</div></div>'
                  f'<div class="eyebrow" style="margin-top:0;color:#5f7571;font-size:12px">{i+1:02d}</div>'
                  f'<h3 style="margin-top:4px">{step}</h3><div class="small muted">{name}</div>'
                  f'<div class="small" style="margin-top:12px;color:#2f4a45;font-style:italic;padding:0 10px">“{q}”</div></div>')
    band = f'<div style="position:relative;height:370px;margin-top:40px">{line}{cells}</div>'

    qs = [("Where am I?", ["ship", "checkpoint"], "The ship on the course, the buoy it last passed."),
          ("Where am I going?", ["route", "destination"], "The course and the pennant at its end."),
          ("What should I do next?", ["compass"], "One needle, one waypoint. Never a list."),
          ("What happens if I fall behind?", ["storm", "safe-harbor"], "Rough water, then shelter. No Game Over."),
          ("How do I get back on track?", ["recalculate", "rhythm"], "A new course to the same pennant; the rhythm waits."),
          ("Am I alone?", ["fleet", "life-buoy", "lighthouse"], "The fleet, the life buoy, and FARO's light."),
          ("Why am I doing this?", ["horizon"], "The horizon: bigger than this course.")]
    qhtml = ""
    for q, keys, txt in qs:
        icons_ = "".join(icon(k, 48) for k in keys)
        qhtml += (f'<div class="card" style="padding:26px 24px">'
                  f'<div class="row" style="gap:12px;height:52px;align-items:center">{icons_}</div>'
                  f'<h3 style="margin-top:18px;font-size:19px">{q}</h3><p class="small muted" style="margin:8px 0 0">{txt}</p></div>')
    qsec = (f'<div class="section"><div class="sechead"><span class="tag">Seven questions</span>'
            f'<h2>Every symbol answers one of them</h2></div>'
            f'<div class="grid" style="grid-template-columns:repeat(7,1fr)">{qhtml}</div></div>')
    close = ('<div class="section" style="display:flex;justify-content:space-between;align-items:flex-end;'
             'background:#1b3b37;border-radius:26px;padding:56px 64px;color:#eef5f2">'
             '<div><div style="font-size:52px;font-weight:500;letter-spacing:-.02em;line-height:1.1">Hard to quit.<br>Easy to return.</div></div>'
             f'<div style="display:flex;align-items:center;gap:26px">{ic(I.recalculate, 96, TEAL, "mint")}'
             '<div style="font-size:24px;line-height:1.45;color:rgba(238,245,242,.8)">No Game Over.<br>'
             '<span style="color:#5bcd8d">Recalculating your route…</span></div></div></div>')
    inner = header("The story", "Read left to right, the icons are one voyage.",
                   "Start → Journey → Direction → Progress → Difficulty → Recovery → Recalculation → New direction → Completion. "
                   "The ship never changes shape; only its situation does. That is the visual DNA of FARO.")
    return page(inner + band + qsec + close, num="02", title="The story")


# ================================================================ BOARD 03
def board_states():
    def col(body, sem, label, text, size=96, pal=LIGHT):
        return (f'<div style="flex:1"><div class="center" style="height:{size+20}px">{ic(body, size, pal, sem)}</div>'
                f'<h3 style="margin-top:16px;text-align:center">{label}</h3>'
                f'<p class="small muted" style="text-align:center;margin:6px 12px 0">{text}</p></div>')
    # checkpoints
    cp = [("completed", "Completed", "Body filled. Done is solid."),
          ("current", "Current", "Top light on. You are here."),
          ("upcoming", "Upcoming", "Outline. Ahead on the course."),
          ("locked", "Not yet open", "Quiet. Visible, not demanding.")]
    buoys = "".join(col(I.buoy(s), "mint", l, t) for s, l, t in cp)
    nodes = "".join(f'<div style="flex:1" class="center">{ic(I.node(s), 44, sem="mint")}</div>' for s, _, _ in cp)
    ck = (f'<div class="card" style="padding:40px 40px 34px"><div class="sechead"><span class="tag">Checkpoints</span>'
          f'<h2>Four states, one colour</h2><span class="muted">The difference is fill, light and weight, not a rainbow.</span></div>'
          f'<div class="row">{buoys}</div>'
          f'<div style="margin-top:26px;padding-top:22px;border-top:1px solid #e1e8e6">'
          f'<div class="small muted" style="margin-bottom:12px">On the route line, the same logic at 22 px:</div>'
          f'<div class="row">{nodes}</div></div></div>')
    # lighthouse
    lh = (f'<div class="card" style="padding:40px 40px 34px;flex:1"><div class="sechead"><span class="tag">Lighthouse</span>'
          f'<h2>Light only when FARO helps</h2></div><div class="row">'
          + col(I.lighthouse("rest"), "mint", "Rest", "In navigation, idle.")
          + col(I.lighthouse("selected"), "mint", "Selected", "FARO tab open: lantern on.")
          + col(I.lighthouse("guiding"), "mint", "Guiding", "Actively helping: beams lit. Rare.")
          + '</div></div>')
    bc = (f'<div class="card" style="padding:40px 40px 34px;flex:.72"><div class="sechead"><span class="tag">Beacon</span>'
          f'<h2>Earned, or not yet</h2></div><div class="row">'
          + col(I.beacon("earned"), "violet", "Earned", "The signal is lit.")
          + col(I.beacon("unearned"), "violet", "Not yet", "Waiting, never missing.")
          + '</div></div>')
    ship = (f'<div class="card" style="padding:40px 40px 34px"><div class="sechead"><span class="tag">Ship</span>'
            f'<h2>The shape never changes. The situation does.</h2></div><div class="row">'
            + col(I.ship_sailing, None, "Sailing", "Normal progress. Calm sea.")
            + col(I.ship_rough, None, "Rough water", "Friction. Heeling, not sinking.")
            + col(I.ship_returning, None, "Returning", "Heading back to harbor.")
            + col(I.ship_new_route, "mint", "New route", "Recalculated course ahead.")
            + '</div></div>')
    # navigation
    tabs = [("compass", "Home"), ("route", "Journey"), ("lighthouse", "FARO"), ("fleet", "Community"),
            ("reward", "Rewards"), ("beacon", "Progress")]
    def tabbar(sel):
        out = ""
        for k, lab in tabs:
            on = k == sel
            if k == "lighthouse":
                body = I.lighthouse("selected" if on else "rest")
            else:
                body = I.ICONS[k][3]()
            color = "#14302c" if on else "#7c908c"
            svg_ = ic(body, 24, LIGHT, SEM[k], color=color, mono=not on)
            out += (f'<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:7px;padding:12px 0;'
                    f'{"background:#e6f7ee;border-radius:14px;" if on else ""}">{svg_}'
                    f'<span style="font-size:12px;font-weight:{500 if on else 400};color:{color}">{lab}</span></div>')
        return f'<div class="card" style="display:flex;padding:8px;border-radius:22px;width:560px">{out}</div>'
    def sidebar(sel):
        out = ""
        for k, lab in tabs:
            on = k == sel
            body = I.lighthouse("selected" if on else "rest") if k == "lighthouse" else I.ICONS[k][3]()
            color = "#eef5f2" if on else "rgba(238,245,242,.62)"
            svg_ = ic(body, 22, TEAL, SEM[k], color=("#eef5f2" if on else "#9bb5ae"), mono=not on)
            out += (f'<div style="display:flex;align-items:center;gap:14px;padding:12px 16px;border-radius:12px;'
                    f'{"background:rgba(255,255,255,.08);box-shadow:inset 3px 0 0 #5bcd8d;" if on else ""}">{svg_}'
                    f'<span style="font-size:15px;color:{color};font-weight:{500 if on else 400}">{lab}</span></div>')
        return f'<div style="background:#1b3b37;border-radius:22px;padding:22px 14px;width:280px">{out}</div>'
    nav = (f'<div class="card" style="padding:40px"><div class="sechead"><span class="tag">Navigation</span>'
           f'<h2>Idle is quiet ink. Selected gains the one accent.</h2></div>'
           f'<div class="row" style="gap:48px;align-items:center">'
           f'<div style="display:flex;flex-direction:column;gap:18px">{tabbar("compass")}{tabbar("lighthouse")}'
           f'<div class="small muted" style="max-width:560px">Side panel, bottom bar. Home = Compass, Journey = Route, '
           f'FARO = Lighthouse, Community = Fleet, Rewards = Reward token, Progress = Beacon. '
           f'The selected tab is the only place colour appears in the bar.</div></div>'
           f'{sidebar("route")}</div></div>')
    inner = header("States", "Subtle, consistent, never alarming.",
                   "Important icons have a fixed set of states. They change by fill, light and weight, the way "
                   "a real buoy or lighthouse would, so a glance is enough and colour stays scarce.")
    return page(inner + f'<div class="section" style="display:flex;flex-direction:column;gap:18px">{ck}'
                f'<div class="row" style="gap:18px">{lh}{bc}</div>{ship}{nav}</div>', num="03", title="States")


# ================================================================ BOARD 04
def board_surfaces():
    keys = list(I.ICONS)
    def strip(pal, bg, label, sub, border=""):
        row = "".join(f'<div class="center" style="width:88px;height:88px">{icon(k, 48, pal)}</div>' for k in keys)
        tc = pal["ink"]
        return (f'<div style="background:{bg};border-radius:22px;padding:30px 36px;{border}">'
                f'<div style="display:flex;justify-content:space-between;color:{tc};margin-bottom:12px">'
                f'<span style="font-weight:500;font-size:17px">{label}</span><span style="font-size:14px;opacity:.65">{sub}</span></div>'
                f'<div style="display:flex;justify-content:space-between">{row}</div></div>')
    pal_chips = [("#14302c", "Teal 950", "Ink · every line", "#fff"), ("#5bcd8d", "Mint", "FARO's light · guidance, active, you-are-here", "#14302c"),
                 ("#1f6b4a", "Forest", "Progress · completed, reached", "#fff"), ("#7a4fb5", "Violet", "Resilience · achievements, rewards", "#fff"),
                 ("#d97a2f", "Orange", "Momentum · rhythm only", "#fff"), ("#f3f6f5", "Paper", "Neutral surfaces", "#14302c")]
    chips = "".join(f'<div style="flex:1"><div style="height:120px;border-radius:18px;background:{c};{"border:1px solid #e1e8e6;" if c=="#f3f6f5" else ""}'
                    f'display:flex;align-items:flex-end;padding:16px;color:{tc};font-size:13px">{c}</div>'
                    f'<h3 style="margin-top:14px;font-size:17px">{n}</h3><div class="small muted">{u}</div></div>'
                    for c, n, u, tc in pal_chips)
    note = ('<p class="small muted" style="margin:18px 0 0;max-width:1100px">Storm has no colour on purpose: difficulty is '
            'never drawn as danger. On light surfaces a mint accent always sits <i>inside</i> an ink line (lantern, sail, '
            'needle) or steps down to mint-600 <b>#2F9A62</b> for free marks and lines, so it keeps 3:1 contrast.</p>')
    surf = (strip(LIGHT, "#f3f6f5", "Paper", "light mode page", "border:1px solid #e1e8e6;")
            + strip(LIGHT, "#ffffff", "Card", "light mode surface", "border:1px solid #e1e8e6;")
            + strip(TEAL, "#1b3b37", "Brand teal", "sidebar, hero, destination")
            + strip(DARK, "#0f1e1b", "Dark", "dark mode page"))
    # discipline comparison
    rainbow = ["#e53e3e", "#3182ce", "#d69e2e", "#805ad5", "#dd6b20", "#38a169", "#d53f8c", "#319795"]
    bad = "".join(ic(I.ICONS[k][3], 44, LIGHT, None, color=c) for k, c in zip(keys[:8], rainbow))
    good = "".join(icon(k, 44) for k in keys[:8])
    cmp_ = (f'<div class="row section" style="gap:18px">'
            f'<div class="card" style="flex:1;padding:32px 36px"><div class="eyebrow" style="color:#b0413e">Avoid</div>'
            f'<h3 style="margin:8px 0 22px">Many colours + noise</h3><div class="row" style="gap:22px;opacity:.9">{bad}</div>'
            f'<p class="small muted" style="margin:20px 0 0">A colour per icon turns the panel into a dashboard and empties colour of meaning.</p></div>'
            f'<div class="card" style="flex:1;padding:32px 36px"><div class="eyebrow">Do</div>'
            f'<h3 style="margin:8px 0 22px">Few colours + strong symbols</h3><div class="row" style="gap:22px">{good}</div>'
            f'<p class="small muted" style="margin:20px 0 0">Ink carries the identity. The accent marks the one thing that matters in each icon.</p></div></div>')
    inner = header("Colour &amp; surfaces", "Few colours. Strong symbols.",
                   "The icons use FARO's existing tokens and nothing else. Ink draws every line; each icon may add "
                   "one semantic accent. The same files work on paper, white cards, the teal sidebar and dark mode.")
    return page(inner + f'<div class="section row" style="gap:18px">{chips}</div>{note}'
                f'<div class="section" style="display:flex;flex-direction:column;gap:16px">{surf}</div>{cmp_}',
                num="04", title="Colour &amp; surfaces")


# ================================================================ BOARD 05
def board_sizes():
    sizes = [16, 20, 24, 32, 48, 96, 128]
    keys = ["lighthouse", "compass", "ship", "route", "safe-harbor", "storm", "recalculate", "fleet", "reward"]
    head = "".join(f'<div style="width:{max(s, 90)+40}px;text-align:center"><div style="font-weight:500">{s} px</div>'
                   f'<div class="small muted">stroke {I.optical_stroke(s):g}</div></div>' for s in sizes)
    rows = ""
    for k in keys:
        cells = "".join(f'<div class="center" style="width:{max(s, 90)+40}px;height:{max(s,40)+22}px">{icon(k, s, mono=s <= 24)}</div>' for s in sizes)
        rows += (f'<div style="display:flex;align-items:center;border-top:1px solid #e1e8e6;padding:6px 0">'
                 f'<div style="width:200px"><h3 style="font-size:17px">{I.ICONS[k][0]}</h3><div class="small muted">{I.ICONS[k][1]}</div></div>{cells}</div>')
    table = (f'<div class="card section" style="padding:36px 40px"><div style="display:flex;padding-bottom:14px">'
             f'<div style="width:200px" class="small muted">Rendered size →</div>{head}</div>{rows}</div>')
    rule = ('<div class="row section" style="gap:18px">'
            + "".join(f'<div class="card" style="flex:1;padding:28px 30px"><div class="eyebrow">{a}</div><h3 style="margin:8px 0">{b}</h3><p class="small muted" style="margin:0">{c}</p></div>'
                      for a, b, c in [("Navigation", "16–24 px", "Silhouette only. The accent drops away unless the item is selected."),
                                      ("Cards", "32–48 px", "The accent appears. Nodes, sails and lanterns fill."),
                                      ("Feature", "64–128 px", "Stroke grows slower than the icon, so large icons stay light and elegant."),
                                      ("Illustration", "256 px +", "Same master. Motion may be added on top, never needed to read it.")])
            + '</div>')
    inner = header("Scale", "Recognisable from 16 px to a hero.",
                   "Each icon is judged first at 16 px. If the silhouette fails there, it is redrawn, not decorated. "
                   "The stroke follows an optical scale instead of growing linearly.")
    return page(inner + table + rule, num="05", title="Scale")


# ================================================================ BOARD 06
def catmull(points):
    d = f"M{points[0][0]:.1f} {points[0][1]:.1f}"
    segs = []
    for i in range(len(points) - 1):
        p0 = points[i - 1] if i > 0 else points[i]
        p1, p2 = points[i], points[i + 1]
        p3 = points[i + 2] if i + 2 < len(points) else p2
        c1 = (p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6)
        c2 = (p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6)
        segs.append(f"M{p1[0]:.1f} {p1[1]:.1f}C{c1[0]:.1f} {c1[1]:.1f} {c2[0]:.1f} {c2[1]:.1f} {p2[0]:.1f} {p2[1]:.1f}")
    return segs


def place(svg_str, x, y, size):
    return f'<g transform="translate({x - size/2:.1f} {y - size/2:.1f})">{svg_str}</g>'


def journey_panel():
    W, H = 460, 640
    pts = [(96, 590), (300, 530), (350, 440), (190, 370), (110, 280), (260, 205), (360, 118)]
    segs = catmull(pts)
    g = f'<svg width="{W}" height="{H}" viewBox="0 0 {W} {H}" fill="none" stroke-linecap="round" stroke-linejoin="round">'
    # sea texture: a few calm lines
    for yy in (470, 318, 160):
        g += f'<path d="{I.wave(24, 170, yy, half=11, amp=3)}" stroke="#e1e8e6" stroke-width="2"/>'
    # done segments
    for s in segs[:3]:
        g += f'<path d="{s}" stroke="#14302c" stroke-width="3"/>'
    # old planned segment (faded) + recalculated segment
    g += f'<path d="{segs[3]}" stroke="#9fb0ac" stroke-width="3" stroke-dasharray="0.1 9" opacity=".7"/>'
    g += '<path d="M190 370C270 350 250 300 210 290S150 258 110 280" stroke="#2f9a62" stroke-width="3" stroke-dasharray="0.1 9"/>'
    for s in segs[4:]:
        g += f'<path d="{s}" stroke="#9fb0ac" stroke-width="3" stroke-dasharray="0.1 9"/>'
    # storm patch where the old course went
    g += place(ic(I.storm, 58), 88, 352, 58)
    # nodes
    states = ["start", "completed", "completed", "current", "upcoming", "locked", "dest"]
    for (x, y), st in zip(pts, states):
        if st == "start":
            g += place(ic(I.harbor, 44), x, y, 44)
        elif st == "dest":
            g += place(ic(I.destination, 64, sem="forest"), x, y - 8, 64)
        else:
            g += place(ic(I.node(st), 40, sem="mint"), x, y, 40)
    # ship at current node
    g += place(ic(I.ship, 58), 256, 350, 58)
    g += '</svg>'
    chip = ('<div style="position:absolute;left:262px;top:300px;background:#e6f7ee;color:#1f6b4a;font-size:12px;font-weight:500;'
            'padding:6px 12px;border-radius:999px">Recalculating your route…</div>')
    labels = ''.join(f'<div style="position:absolute;left:{x}px;top:{y}px;font-size:12px;color:#5f7571">{t}</div>'
                     for x, y, t in [(118, 600, "Start"), (318, 540, "M1 · Fundamentos"), (370, 446, "M2 · Alcance"),
                                     (58, 262, "M4"), (284, 190, "M5"), (300, 44, "Destination"), (92, 398, "M3 · you are here")])
    return f'<div style="position:relative;width:{W}px;height:{H}px">{g}{chip}{labels}</div>'


def journey_strip():
    states = ["completed", "completed", "current", "upcoming", "upcoming", "locked"]
    nodes = ""
    for i, st in enumerate(states):
        nodes += ic(I.node(st), 30, sem="mint")
        if i < len(states) - 1:
            solid = i < 2
            dash = "" if solid else 'stroke-dasharray="0.1 6"'
            col = "#14302c" if solid else "#9fb0ac"
            nodes += (f'<svg width="30" height="4" style="flex:1"><path d="M2 2H28" stroke="{col}" '
                      f'stroke-width="2" stroke-linecap="round" {dash}/></svg>')
    nodes += ic(I.destination, 34, sem="forest")
    return (f'<div class="card" style="padding:18px 20px;margin-top:14px;border-radius:18px">'
            f'<div style="display:flex;justify-content:space-between"><span style="font-weight:500">Module 3 of 6</span>'
            f'<span class="small muted">Gestión de proyectos</span></div>'
            f'<div style="display:flex;align-items:center;gap:2px;margin-top:14px">{nodes}</div></div>')


def phone(title, body, tab_sel):
    tabs = [("compass", "Home"), ("route", "Journey"), ("lighthouse", "FARO"), ("fleet", "Community"),
            ("reward", "Rewards"), ("beacon", "Progress")]
    tb = ""
    for k, lab in tabs:
        on = k == tab_sel
        body_ = I.lighthouse("selected" if on else "rest") if k == "lighthouse" else I.ICONS[k][3]()
        color = "#14302c" if on else "#7c908c"
        tb += (f'<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:5px;padding:9px 0;'
               f'{"background:#e6f7ee;border-radius:12px;" if on else ""}">{ic(body_, 22, LIGHT, SEM[k], color=color, mono=not on)}'
               f'<span style="font-size:11px;color:{color};font-weight:{500 if on else 400}">{lab}</span></div>')
    return (f'<div style="width:520px;background:#f3f6f5;border-radius:34px;border:1px solid #dbe4e1;overflow:hidden;'
            f'box-shadow:0 24px 60px rgba(20,48,44,.14);display:flex;flex-direction:column;height:860px">'
            f'<div style="padding:26px 30px 10px;display:flex;align-items:center;gap:12px">{brand_glyph(30)}'
            f'<span style="font-weight:600;letter-spacing:.14em;font-size:15px">FARO</span>'
            f'<span class="muted" style="margin-left:auto;font-size:13px">{title}</span></div>'
            f'<div style="padding:10px 22px 18px;flex:1">{body}</div>'
            f'<div style="display:flex;background:#fff;margin:0 14px 14px;border-radius:18px;padding:6px;'
            f'box-shadow:0 -6px 24px rgba(20,48,44,.06)">{tb}</div></div>')


def board_context():
    # phone 1: home
    home = (f'<div class="card" style="padding:22px;border-radius:18px;background:#1b3b37;color:#eef5f2">'
            f'<div style="display:flex;gap:14px;align-items:center">{ic(I.horizon, 40, TEAL, "mint")}'
            f'<div><div style="font-size:12px;letter-spacing:.16em;opacity:.65">YOUR HORIZON</div>'
            f'<div style="font-size:18px;font-weight:500">Career growth</div></div></div></div>'
            f'<div class="card" style="padding:22px;margin-top:14px;border-radius:18px;box-shadow:inset 3px 0 0 #5bcd8d,0 10px 28px rgba(20,48,44,.06)">'
            f'<div style="display:flex;gap:14px;align-items:center">{ic(I.compass, 44)}'
            f'<div><div class="eyebrow" style="font-size:11px">Next best action</div>'
            f'<div style="font-size:18px;font-weight:500">Review Module 2</div>'
            f'<div class="small muted">10 min · keeps your journey moving</div></div></div></div>'
            f'<div class="row" style="margin-top:14px;gap:14px">'
            f'<div class="card" style="flex:1;padding:18px;border-radius:18px"><div style="display:flex;gap:10px;align-items:center">'
            f'{ic(I.rhythm, 32, sem="orange")}<div><div style="font-size:20px;font-weight:500">78%</div><div class="small muted">Rhythm</div></div></div></div>'
            f'<div class="card" style="flex:1;padding:18px;border-radius:18px"><div style="display:flex;gap:10px;align-items:center">'
            f'{ic(I.route, 32, sem="forest")}<div><div style="font-size:20px;font-weight:500">42%</div><div class="small muted">Journey</div></div></div></div></div>'
            f'<div class="card" style="padding:18px 20px;margin-top:14px;border-radius:18px;display:flex;align-items:center;gap:14px">'
            f'{ic(I.lighthouse("guiding"), 44)}<div class="small" style="color:#2f4a45">“You have 15 minutes today. Let’s do the one thing that moves you forward.”</div></div>'
            + journey_strip() +
            f'<div style="display:flex;gap:10px;margin-top:14px">'
            f'<div style="flex:1;border:1px solid #dbe4e1;border-radius:14px;padding:12px 14px;display:flex;gap:10px;align-items:center;background:#fff">{ic(I.life_buoy, 26)}<span class="small">SOS</span></div>'
            f'<div style="flex:1;border:1px solid #dbe4e1;border-radius:14px;padding:12px 14px;display:flex;gap:10px;align-items:center;background:#fff">{ic(I.fleet, 26)}<span class="small">Study room</span></div></div>')
    # phone 2: recovery
    rec = (f'<div style="background:#1b3b37;border-radius:20px;padding:30px 26px;color:#eef5f2">'
           f'{ic(I.safe_harbor, 84, TEAL, "mint")}'
           f'<div style="font-size:26px;font-weight:500;margin-top:14px;letter-spacing:-.01em">Welcome back.</div>'
           f'<div style="font-size:16px;opacity:.78;margin-top:4px">Your progress is still here.</div></div>'
           f'<div class="card" style="padding:20px 22px;margin-top:14px;border-radius:18px">'
           f'<div style="display:flex;gap:14px;align-items:center">{ic(I.recalculate, 44)}'
           f'<div><div style="font-size:17px;font-weight:500">Recalculating your route…</div>'
           f'<div class="small muted">12 days · 4 modules · 30 min a day</div></div></div></div>'
           f'<div class="card" style="padding:20px 22px;margin-top:14px;border-radius:18px">'
           f'<div class="eyebrow" style="font-size:11px">Comeback mission</div>'
           f'<div style="display:flex;gap:14px;align-items:center;margin-top:10px">{ic(I.compass, 40)}'
           f'<div><div style="font-size:17px;font-weight:500">Reconnect in 10 minutes</div>'
           f'<div class="small muted">Three quick cards on what you already know</div></div></div></div>'
           f'<div class="card" style="padding:18px 22px;margin-top:14px;border-radius:18px">'
           f'<div class="small muted" style="margin-bottom:12px">Resilience</div><div class="row" style="gap:12px">'
           + "".join(medal(b, l, on) for b, l, on in [(I.ship_returning, "The Comeback", True), (I.ship_new_route, "Back on Track", False),
                                                    (I.ship_rough, "Weathered the Storm", False), (I.compass, "Smart Session", True)])
           + '</div></div>')
    # phone 3: journey
    jr = f'<div style="margin:-6px -8px 0">{journey_panel()}</div>'
    phones = (f'<div class="section" style="display:flex;justify-content:space-between;align-items:flex-start">'
              f'{phone("Home", home, "compass")}{phone("Recovery", rec, "lighthouse")}{phone("Journey", jr, "route")}</div>')
    inner = header("In use", "The language, working inside FARO.",
                   "The same sixteen symbols, in the three moments that matter most: deciding what to do today, "
                   "coming back after time away, and seeing the whole voyage. Mockups for direction, not final UI.")
    return page(inner + phones, num="06", title="In use")


def medal(fn, label, on):
    ring = "#7a4fb5" if on else "#c9d6d2"
    body = fn() if callable(fn) else fn
    inner = ic(body, 34, LIGHT, "mint" if on else None, color="#14302c" if on else "#9fb0ac", mono=not on)
    return (f'<div style="flex:1;text-align:center"><div style="width:64px;height:64px;margin:0 auto;border-radius:32px;'
            f'border:2.4px solid {ring};display:flex;align-items:center;justify-content:center;'
            f'{"background:#eee7f8;" if on else ""}">{inner}</div>'
            f'<div style="font-size:11px;margin-top:8px;color:{"#14302c" if on else "#9fb0ac"};line-height:1.3">{label}</div></div>')


BOARDS = {
    "00-overview": board_overview,
    "01-construction": board_construction,
    "02-story": board_story,
    "03-states": board_states,
    "04-colour-and-surfaces": board_surfaces,
    "05-scale": board_sizes,
    "06-in-use": board_context,
}


# ================================================================ BOARD 07
def board_checklist():
    qs = ["Clear meaning", "FARO family", "Premium", "For adults", "No childish game", "No gradient needed",
          "Works solid", "Light mode", "Dark mode", "Small sizes", "Low noise", "Navigation metaphor",
          "Persistence", "Support, not judgment", "Alive, not heavy"]
    watch = {
        ("harbor", 0): "An anchor says harbor at once; start needs its context (onboarding, route start).",
        ("destination", 0): "Pennant on a hill could read as a summit. The water line carries it; confirm in the 5-user test.",
        ("recalculate", 0): "Pair it with the words Recalculating your route the first time it appears.",
        ("safe-harbor", 9): "Under 24 px use the nav cut: the dotted shelter drops.",
        ("beacon", 9): "Pulse arcs merge under 20 px. Use from 32 px (cards, achievements).",
    }
    head = "".join(f'<th style="writing-mode:vertical-rl;transform:rotate(180deg);font-weight:500;font-size:13px;padding:10px 0;height:170px;text-align:left;color:#2f4a45">{i+1}. {q}</th>' for i, q in enumerate(qs))
    rows = ""
    notes = []
    for k, (name, use, tier, fn) in I.ICONS.items():
        cells = ""
        for qi in range(len(qs)):
            if (k, qi) in watch:
                notes.append((name, qs[qi], watch[(k, qi)]))
                cells += ('<td class="center" style="height:52px"><svg width="22" height="22" viewBox="0 0 22 22"><circle cx="11" cy="11" r="8" fill="none" stroke="#d97a2f" stroke-width="2"/>'
                          '<path d="M11 3a8 8 0 0 1 0 16Z" fill="#d97a2f"/></svg></td>')
            else:
                cells += ('<td style="height:52px;text-align:center"><svg width="20" height="20" viewBox="0 0 20 20" style="display:inline-block"><path d="m5 10.5 3.2 3.2L15 6.8" fill="none" '
                          'stroke="#2f9a62" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg></td>')
        rows += (f'<tr style="border-top:1px solid #e1e8e6"><td style="padding:6px 0;width:60px">{icon(k, 32)}</td>'
                 f'<td style="width:190px"><div style="font-weight:500">{name}</div><div class="small muted">Tier {tier}</div></td>{cells}</tr>')
    table = (f'<div class="card section" style="padding:30px 40px"><table style="border-collapse:collapse;width:100%">'
             f'<tr><th></th><th></th>{head}</tr>{rows}</table></div>')
    nt = "".join(f'<div class="card" style="flex:1;padding:24px 26px"><div class="eyebrow" style="color:#c96a24">{n} · {q}</div>'
                 f'<p class="small" style="margin:10px 0 0;color:#2f4a45">{t}</p></div>' for n, q, t in notes)
    inner = header("Approval", "Every icon against the fifteen questions.",
                   "A tick means it passes as drawn. A half-circle marks a watch item: it passes with a usage rule, "
                   "or it should be confirmed with the five-user prototype test before it is final. Nothing here is "
                   "validated by users yet.")
    return page(inner + table + f'<div class="row section" style="gap:14px">{nt}</div>', num="07", title="Approval")


BOARDS["07-approval"] = board_checklist


async def render(names, outdir, scale=2):
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await b.new_page(viewport={"width": 1920, "height": 1080}, device_scale_factor=scale)
        for n in names:
            await pg.set_content(BOARDS[n]())
            await pg.wait_for_timeout(150)
            el = await pg.query_selector(".board")
            await el.screenshot(path=f"{outdir}/faro-icons-{n}.png")
            print("rendered", n)
        await b.close()


if __name__ == "__main__":
    names = sys.argv[2:] or list(BOARDS)
    asyncio.run(render(names, sys.argv[1] if len(sys.argv) > 1 else ".", scale=1))
